jQuery('#fb_wpress_connect_btn').live('click', function(event) {
	event.preventDefault();
	fb_wpress_connect();
});

function fb_wpress_connect() {
	FB.login(function(response) {
	  if (response.authResponse) {
	  	on_fb_connect();
	  }
	  else {
	  }
	}, {scope:'read_stream,publish_stream,offline_access,email,user_about_me,user_birthday'});
}

function on_fb_connect() {
	jQuery.post(
		MyAjax.ajaxurl,
		{ action : 'on_fb_connect'},
		function( response ) {
			//jQuery('#wrapper').prepend(response);
			if(response!='') alert(response);
			window.location.reload();
		}
	);
}

jQuery('#fb_wpress_logout_btn').live('click', function(event) {
	event.preventDefault();
	on_fb_logout();
});

function on_fb_logout() {
	jQuery.post(
		MyAjax.ajaxurl,
		{ action : 'on_fb_logout'},
		function( response ) {
			FB.logout(function(response) {
			  window.location.reload();
			});
		}
	);
}

jQuery('#fb_wpress_disconnect_user_btn').live('click', function(event) {
	event.preventDefault();
	jQuery.ajax({
		type: 'POST',
		url: MyAjax.ajaxurl,
		data: 'action=disconnect_fb_user',
		success: function(msg) {
			var flag = 1;
			FB.logout(function(response) {
			  window.location.reload();
			  flag=0;
			});
			if(flag==1) window.location.reload();
		}
	});
});


jQuery('#updateBtn').live('click', function(event) {
	event.preventDefault();
	update_status_users_behaf();
});

function update_status_users_behaf() {
	var updateBtn = jQuery('#updateBtn');
	var status_to_update = jQuery('#status_to_update').val();
	var link_to_update = jQuery('#link_to_update').val();
	var picture_to_update = jQuery('#picture_to_update').val();
	var name_to_update = jQuery('#name_to_update').val();
	var caption_to_update = jQuery('#caption_to_update').val();
	var description_to_update = jQuery('#description_to_update').val();
	
	link_to_update = link_to_update;
	picture_to_update = picture_to_update;
	name_to_update = name_to_update;
	caption_to_update = caption_to_update;
	description_to_update = description_to_update;
	
	/*
	link_to_update = encodeURIComponent(link_to_update);
	picture_to_update = encodeURIComponent(picture_to_update);
	name_to_update = encodeURIComponent(name_to_update);
	caption_to_update = encodeURIComponent(caption_to_update);
	description_to_update = encodeURIComponent(description_to_update);
	*/
	
	//source_to_update = escape(source_to_update);
	
	if(status_to_update=='') {
		alert('Please type a status first.');
	}
	else {
		jQuery('#status_to_update').attr('disabled','disabled');
		jQuery('#link_to_update').attr('disabled','disabled');
		jQuery('#picture_to_update').attr('disabled','disabled');
		jQuery('#name_to_update').attr('disabled','disabled');
		jQuery('#caption_to_update').attr('disabled','disabled');
		jQuery('#description_to_update').attr('disabled','disabled');
		jQuery('#source_to_update').attr('disabled','disabled');
		jQuery('#updateBtn').attr('disabled','disabled');
		
		jQuery.post(
			MyAjax.ajaxurl,
			{ action : 'update_status_users_behaf', status: status_to_update, link: link_to_update, picture: picture_to_update, name: name_to_update, caption: caption_to_update, description: description_to_update },
			function( response ) {
				//alert(response);
				if(response!='0') {
					//alert(response);
					alert('The updates have been published.');
				}
				jQuery('#status_to_update').removeAttr('disabled');
				jQuery('#link_to_update').removeAttr('disabled');
				jQuery('#picture_to_update').removeAttr('disabled');
				jQuery('#name_to_update').removeAttr('disabled');
				jQuery('#caption_to_update').removeAttr('disabled');
				jQuery('#description_to_update').removeAttr('disabled');
				//jQuery('#source_to_update').removeAttr('disabled');
				jQuery('#updateBtn').removeAttr('disabled');
				jQuery('#status_to_update').val('');
				jQuery('#link_to_update').val('');
				jQuery('#picture_to_update').val('');
				jQuery('#name_to_update').val('');
				jQuery('#caption_to_update').val('');
				jQuery('#description_to_update').val('');
				//jQuery('#source_to_update').val('');
			}
		);
	}
}