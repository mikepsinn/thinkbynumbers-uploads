<?php
/*
Plugin Name: Facebook WPress
Plugin URI: http://yougapi.com/products/wp/facebook_wpress/
Description: Integrate Facebook connect and Facebook social functionnalities to your WordPress.
Version: 2.0
Author: Yougapi Technology LLC
Author URI: http://yougapi.com
*/

define(FACEBOOK_WPRESS_ADMIN_ID, 'facebook_wpress_admin_id');
define(FACEBOOK_WPRESS_ADMIN_AUTOPOST, 'facebook_wpress_admin_autopost');

require_once dirname( __FILE__ ).'/include/wpress_framework/WPress_framework.php';
require_once dirname( __FILE__ ).'/facebook_wpress_wp.php';
require_once dirname( __FILE__ ).'/facebook_wpress_widget.php';
require_once dirname( __FILE__ ).'/facebook_wpress_avatar.php';
require_once dirname( __FILE__ ).'/facebook_wpress_db.php';
require_once dirname( __FILE__ ).'/facebook_wpress_dashboard.php';
require_once dirname( __FILE__ ).'/include/webzone.php';

//if it's in the admin section
if(is_admin()) {
	require_once dirname( __FILE__ ).'/facebook_wpress_admin.php';
	//create table on plugin activation (if table doesn't exist)
	register_activation_hook(__FILE__, array('Facebook_wpress', 'on_plugin_activation'));
}

//include javascripts
add_action( 'wp_print_scripts', array('Facebook_wpress', 'add_js_scripts') );

//instantialize the class
new Facebook_wpress();
//load the Javascript SDK
add_action('wp_footer',array('Facebook_wpress', 'loadJsSDK'),20);


class Facebook_wpress {
	
	function Facebook_wpress() {
		$this->setFacebookAppData();
		//shortcode
		add_shortcode( 'fb_wpress_connect', array(__CLASS__, 'display_connect_link_shortcode') );
		//add_action('wp_footer', array(__CLASS__, 'add_onload'));
	}
	
	function add_js_scripts() {
		wp_enqueue_script( 'facebook_wpress_ajax', plugin_dir_url( __FILE__ ) . 'ajax.js', array( 'jquery' ) );
		wp_localize_script( 'facebook_wpress_ajax', 'MyAjax', array( 'ajaxurl' => admin_url('admin-ajax.php') ) );
	}
	
	/*
	function add_onload() {
	    ?>
	    <script type="text/javascript">
	    my_onload_callback = function() {
	    	<?php echo $GLOBALS['fb_wpress_js_on_ready']; ?>
	    };
		
	    if( typeof jQuery == "function" ) { 
	        jQuery(my_onload_callback); // document.ready
	    }
	    else {
	        document.getElementsByTagName('body')[0].onload = my_onload_callback; // body.onload
	    }
	    
	    </script>
	    <?php
	}
	*/
	
	function display_connect_link_shortcode($atts, $content = null, $code) {
		extract(shortcode_atts(array(
		'image_url' => '',
		'text' => '',
		'connected_display' => '',
		), $atts));
		
		if($connected_display=='false') $connected_display='0';
		else $connected_display='1';
		
		$criteria['image_url'] = $image_url;
		$criteria['text'] = $text;
		$criteria['connected_display'] = $connected_display;
		$display = self::get_connect_link_display($criteria);
		
		$content = '<p>'.$display.'</p>';
		return $content;
	}
	
	function display_connect_link($criteria='') {
		$image_url = $criteria['image_url'];
		$text = $criteria['text'];
		$connected_display = $criteria['connected_display'];
		$display = self::get_connect_link_display($criteria);
		echo $display;
	}
	
	function get_connect_link_display($criteria='') {
		$image_url = $criteria['image_url'];
		$text = $criteria['text'];
		$connected_display = $criteria['connected_display'];
		$widget_flag = $criteria['widget_flag'];
		
		if($connected_display=='') $connected_display=1;
		
		$display = '';
		
		if(FACEBOOK_APP_ID!='' && FACEBOOK_SECRET!='') {
			$f1 = new Facebook_class();
			$fb_cookie = $f1->getCookie();
			
			if($widget_flag=='1') $style = 'align="left" style="padding-right:5px;"';
			else $style = 'style="padding-right:5px; vertical-align: middle;"';
			
			$user = wp_get_current_user();
			$wp_id = $user->ID;
			
			$db1 = new Facebook_wpress_db();
			$fb_user = $db1->get_fb_user($wp_id);
			
			if(is_user_logged_in() && $fb_cookie!='' && count($fb_user)>0) {
				if($connected_display=='1') {
					$user_data = $f1->getUserData();
					$fb_userid = $user_data['id'];
					$fb_full_name = $user_data['name'];
					$fb_profile_picture = $user_data['picture'];
					$fb_link = $user_data['link'];
					$display .= '<a href="'.$fb_link.'" title="'.$fb_full_name.'" target="_blank"><img src="'.$fb_profile_picture.'" width=46 '.$style.'></a> ';
					$display .= 'Connected as '.$fb_full_name.' (<small><a href="#" id="fb_wpress_logout_btn">Log out</a>
					 - <a href="'.admin_url('profile.php').'">Settings</a></small>)';
				}
			}
			else {
				$display .= '<a href="#" id="fb_wpress_connect_btn" title="Connect with Facebook">';
				if($text!='') {
					$display .= $text;
				}
				else {
					if($image_url=='') $display .= '<img src="'.plugin_dir_url( __FILE__ ).'include/graph/facebook-connect.png" border=0>';
					else $display .= '<img src="'.$image_url.'" border=0>';
				}
				$display .= '</a>';
			}
		}
		return $display;
	}
	
	function on_plugin_activation() {
		$f1 = new Facebook_wpress_widget();
		$f1->setDefaultValues();
		$fa1 = new Facebook_wpress_admin();
		$fa1->init_table();
	}
	
	function setFacebookAppData() {
		$options = get_option(FACEBOOK_WPRESS_ADMIN_ID);
		$fb_app_id = $options['fb_app_id'];
		$fb_app_secret = $options['fb_app_secret'];
		define(FACEBOOK_APP_ID, $fb_app_id);
		define(FACEBOOK_SECRET, $fb_app_secret);
	}
	
	function loadJsSDK() {
		$f1 = new Facebook_class();
		$f1->loadJsSDK();
	}
}

?>