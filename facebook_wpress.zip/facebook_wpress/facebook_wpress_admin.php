<?php

class Facebook_wpress_admin extends WPress_framework {
	
	function Facebook_wpress_admin() {
		add_filter( 'plugin_action_links', array(__CLASS__, 'plugin_action_links'), 10, 2);
		add_action( 'admin_menu', array(__CLASS__, 'config_page_init') );
		
		add_action( 'wp_ajax_nopriv_update_status_users_behaf', array(__CLASS__,'update_status_users_behaf') );
		add_action( 'wp_ajax_update_status_users_behaf', array(__CLASS__,'update_status_users_behaf') );
		
		add_action('admin_print_scripts', array(__CLASS__,'config_page_scripts'));
	}
	
	function config_page_scripts() {
		//wp_deregister_script('dashboard');
		wp_enqueue_script('dashboard');
	}
	
	function init_table() {
		require_once dirname( __FILE__ ).'/facebook_wpress_db.php';
		$db1 = new Facebook_wpress_db();
		$db1->createTable();
		$db1->checkTableFields();
	}
	
	function config_page_init() {
		if (function_exists('add_submenu_page'))
			add_submenu_page('plugins.php', 'Facebook WPress', 'Facebook WPress', 'manage_options', 'facebook-press-config', array('Facebook_wpress_admin', 'config_page_display'));
	}
	
	function config_page_display() {
		
		$post_options = $_POST[FACEBOOK_WPRESS_ADMIN_ID];
		if ($post_options['submit']) {
			$options['fb_app_id'] = $post_options['fb_app_id'];
			$options['fb_app_secret'] = $post_options['fb_app_secret'];
			update_option(FACEBOOK_WPRESS_ADMIN_ID, $options);
		}
		
		$options = get_option(FACEBOOK_WPRESS_ADMIN_ID);
		$fb_app_id = $options['fb_app_id'];
		$fb_app_secret = $options['fb_app_secret'];
		
		?>
		
		<div class="wrap">
		<div class="metabox-holder">
		
		<br>
		<?php
		echo '<a href="http://yougapi.com"><img src="'.plugin_dir_url( __FILE__ ).'include/graph/facebook-wpress-mini.png" align="left" style="margin-right:15px;" /></a>';
		?>
		<h2>Facebook WPress configuration</h2>
		<hr style="background:#ddd;color:#ddd;height:1px;border:none;">
		<br><br>
		
			<table width="100%"><tr><td valign="top" width="50%">
				
				<?php
				$criteria['key'] = FACEBOOK_WPRESS_ADMIN_ID;
				$criteria['box_title'] = 'General Plugin Settings';
				$criteria['fields'][] = array('name'=>'fb_app_id', 'title'=>'Facebook application id');
				$criteria['fields'][] = array('name'=>'fb_app_secret', 'title'=>'Facebook application secret');
				$criteria['fields'][] = array('name'=>'fb_avatar', 'title'=>'Set Facebook pictures as users avatar', 'type'=>'checkbox');
				parent::display_admin_control($criteria);
				?>
				
				<?php
				
				//display connected users icons
				$fadmin = new Facebook_wpress_db();
				$users = $fadmin->getConnectedUsers();
				
				echo '<div class="meta-box-sortables"><div class="postbox" style="width:100%;">';
				echo '<div class="handlediv" title="Click to toggle"><br /></div>';
				echo '<h3 class="hndle"><span>Facebook users who have connected to your app ('.count($users).')</span></h3>';
					
					$max_users_icons = 50;
					if($max_users_icons>count($users)) $max_users_icons=count($users);
					
					echo '<div class="inside" style="width:100%; padding:10px;">';
						for($i=0;$i<$max_users_icons;$i++) {
							$name = $users[$i]['name'];
							$picture = $users[$i]['picture'];
							$url = $users[$i]['url'];
							$created = $users[$i]['created'];
							
							echo '<a href="'.$url.'" target="_blank" title="'.$name.' (connected on '.$created.')">';
							echo '<img src="'.$picture.'" width="36" style="padding:2px;">';
							echo '</a>';
						}
						if(count($users)>50) echo '<div style="margin-top:10px;"><small>Only the latest 50 user\'s icons are displayed</small></div>';
					echo '</div>';
				echo '</div></div>';
				
				//display users emails
				$users = $fadmin->getAllUsers();
				
				echo '<div class="meta-box-sortables"><div class="postbox" style="width:100%;">';
				echo '<div class="handlediv" title="Click to toggle"><br /></div>';
				echo '<h3 class="hndle"><span>User\'s emails</span></h3>';
					
					$user_emails='';
					for($i=0;$i<count($users);$i++) {
						$email = $users[$i]['email'];
						$user_emails .= $email;
						if($i<count($users)-1) $user_emails .= ', ';
					}
					
					echo '<div class="inside" style="width:100%; padding:10px;">';
						echo '<textarea style="width:96%; height:120px;">'.$user_emails.'</textarea>';
					echo '</div>';
					
				echo '</div></div>';
				
				
				$criteria_autopost['key'] = FACEBOOK_WPRESS_ADMIN_AUTOPOST;
				$criteria_autopost['box_title'] = 'Autopost on Facebook user\'s wall';
				$criteria_autopost['fields'][] = array('name'=>'autopost', 'title'=>'Activate the autopost when a user connects for the first time', 'type'=>'checkbox');
				$criteria_autopost['fields'][] = array('name'=>'link', 'title'=>'Link to attach to the message<small>(optional)</small>');
				$criteria_autopost['fields'][] = array('name'=>'picture', 'title'=>'URL of the image to use with the message <small>(optional)</small>');
				$criteria_autopost['fields'][] = array('name'=>'message', 
				'title'=>'Message to post <small>(you can use <font color="blue">{first_name}</font> and <font color="blue">{last_name}</font> to post users real names in the message.)</small>', 
				'type'=>'textarea');
				parent::display_admin_control($criteria_autopost);
				
				
				echo '<small>Plugin created by <a href="http://yougapi.com">Yougapi Technology</a></small>';
				
			echo '</td>';
			
			
			//right side
			echo '<td style="padding-left:40px; valign="top; width:50%;" valign="top">';
			
				echo '<div class="meta-box-sortables"><div class="postbox" style="width:100%;">';
				echo '<div class="handlediv" title="Click to toggle"><br /></div>';
				echo '<h3 class="hndle"><span>Update status on behaf of your users</span></h3>';
				
					echo '<div style="width:95%; padding:10px;">';
					//status
					echo '<p style="padding-left:5px;"><label>Status: <small>(max 420 characters)</small></label></p>';
					echo '<textarea id="status_to_update" style="width:100%; height:100px"></textarea>';
					//link
					echo '<p style="padding-left:5px;"><label>Link: <small>(optional - should starts with http://)</small></label></p>';
					echo '<input id="link_to_update" type="text" value="" style="width:100%;">';
					//picture
					echo '<p style="padding-left:5px;"><label>Picture: <small>(optional - should starts with http://)</small></label></p>';
					echo '<input id="picture_to_update" type="text" value="" style="width:100%;">';
					//name
					echo '<p style="padding-left:5px;"><label>Name: <small>(optional - the name of the link)</small></label></p>';
					echo '<input id="name_to_update" type="text" value="" style="width:100%;">';
					//caption
					echo '<p style="padding-left:5px;"><label>Caption: <small>(optional - the caption of the link (appears beneath the link name))</small></label></p>';
					echo '<input id="caption_to_update" type="text" value="" style="width:100%;">';
					//description
					echo '<p style="padding-left:5px;"><label>Description: <small>(optional - a description of the link (appears beneath the link caption))</small></label></p>';
					echo '<textarea id="description_to_update" value="" style="width:100%; height:50px;"></textarea>';
					/*
					//source (video)
					echo '<p style="padding-left:5px;"><label>Video url: <small>(optional - YouTube link etc)</small></label></p>';
					echo '<input id="source_to_update" type="text" value="" style="width:100%;">';
					*/
					//update
					echo '<p class="submit" style="padding-bottom:0px; padding-top:5px;">
					<input type="submit" id="updateBtn" value="Update status"></p>';
					echo '</div>';
				echo '</div></div>';
			
			echo '</td></tr></table>';
		
		echo '</div></div>';
	}
	
	function update_status_users_behaf() {
		$status = stripslashes($_POST['status']);
		$link = stripslashes($_POST['link']);
		$picture = stripslashes($_POST['picture']);
		$name = stripslashes($_POST['name']);
		$caption = stripslashes($_POST['caption']);
		$description = stripslashes($_POST['description']);
		$source = stripslashes($_POST['source']);
		
		//echo $status.' || '.urldecode($caption);
		
		if($link=='http://') $link='';
		if($picture=='http://') $picture='';
		if($source=='http://') $source='';
		
		if(current_user_can('activate_plugins')&&$status!='') {
			
			$fadmin = new Facebook_wpress_db();
			$users = $fadmin->getConnectedUsers();
			
			$f1 = new Facebook_class();
			
			for($i=0;$i<count($users);$i++) {
				$fb_token = $users[$i]['fb_token'];
				$fb_id = $users[$i]['fb_id'];
				$f1->updateFacebookStatus(array('fb_id'=>$fb_id, 'message'=>$status, 'link'=>$link, 'picture'=>$picture, 'name'=>$name, 'caption'=>$caption, 'description'=>$description, 'source'=>$source), $fb_token);
			}
			
			echo '1';
			exit;
		}
		else {
			echo '0';
			exit;
		}
		
	}
	
	function plugin_action_links($links, $file) {
		if ( $file == plugin_basename( dirname(__FILE__).'/facebook_wpress.php' ) ) {
			$links[] = '<a href="plugins.php?page=facebook-press-config">Settings</a>';
		}
		return $links;
	}
	
}

new Facebook_wpress_admin();

?>