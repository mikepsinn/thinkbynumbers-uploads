<?php


class Facebook_wpress_dashboard {
	
	function Facebook_wpress_dashboard() {
		//display connect button in user's dashboard
		add_action('profile_personal_options', array(__CLASS__, 'display_fb_connect'));
		//disconnect user
		add_action( 'wp_ajax_nopriv_disconnect_fb_user', array(__CLASS__,'disconnect_fb_user') );
		add_action( 'wp_ajax_disconnect_fb_user', array(__CLASS__,'disconnect_fb_user') );
	}
	
	function display_fb_connect() {
		
		$f1 = new Facebook_wpress();
		$f1->loadJsSDK();
		
		echo '<table class="form-table">';
			echo '<tr>';
				echo '<th><label>Facebook Connect</label></th>';
				echo '<td><p>';
				
				$user = wp_get_current_user();
				$wp_id = $user->ID;
				
				$db1 = new Facebook_wpress_db();
				$fb_user = $db1->get_fb_user($wp_id);
				
				if(count($fb_user)>0) {
					$fb_userid = $fb_user[0]['fb_id'];
					$fb_full_name = $fb_user[0]['fb_name'];
					$fb_profile_picture = 'http://graph.facebook.com/'.$fb_userid.'/picture';
					echo '<img src="'.$fb_profile_picture.'" width=46 style="vertical-align:middle;"> ';
					echo 'Connected as '.$fb_full_name.' (<small><a href="#" id="fb_wpress_disconnect_user_btn">Disconnect</a></small>)';
				}
				else {
					echo '<a href="#" id="fb_wpress_connect_btn" title="Connect with Facebook">';
					echo '<img src="'.plugin_dir_url( __FILE__ ).'include/graph/facebook-connect.png" border=0>';
					echo '</a>';
				}
				
				echo '</p></td>';
			echo '</tr>';
		echo '</table>';
	}
	
	//AJAX call
	function disconnect_fb_user() {
		$user = wp_get_current_user();
		$wp_id = $user->ID;
		$db1 = new Facebook_wpress_db();
		$db1->delete_fb_user($wp_id);
		exit;
	}
	
}

new Facebook_wpress_dashboard();

?>