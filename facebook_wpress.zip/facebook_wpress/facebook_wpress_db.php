<?php

//AJAX store Facebook data
add_action( 'wp_ajax_nopriv_on_fb_connect', array('Facebook_wpress_db','on_fb_connect') );
add_action( 'wp_ajax_on_fb_connect', array('Facebook_wpress_db','on_fb_connect') );

add_action( 'wp_ajax_nopriv_on_fb_logout', array('Facebook_wpress_db','on_fb_logout') );
add_action( 'wp_ajax_on_fb_logout', array('Facebook_wpress_db','on_fb_logout') );

class Facebook_wpress_db {
	
	function getConnectedUsers($criteria=array()) {
		global $wpdb;
		
		$fb_token_expires = $criteria['fb_token_expires'];
		
		if($fb_token_expires=='') $fb_token_expires=0;
		
		$table_name = $wpdb->prefix . "facebook_wpress";
		$now = time();
		$sql = "SELECT * FROM $table_name WHERE fb_token_expires='$fb_token_expires' OR fb_token_expires>'$now' ORDER BY created DESC";
		$results = $wpdb->get_results($wpdb->prepare($sql));
		for($i=0;$i<count($results);$i++) {
			$data[$i]['fb_id'] = $results[$i]->fb_id;
			$data[$i]['name'] = $results[$i]->fb_name;
			$data[$i]['email'] = $results[$i]->fb_email;
			$data[$i]['picture'] = 'https://graph.facebook.com/'.$results[$i]->fb_id.'/picture';
			$data[$i]['url'] = 'https://www.facebook.com/profile.php?id='.$results[$i]->fb_id;
			$data[$i]['fb_token'] = $results[$i]->fb_token;
			$data[$i]['fb_token_expires'] = $results[$i]->fb_token_expires;
			$data[$i]['created'] = $results[$i]->created;
		}
		return $data;
	}
	
	function getAllUsers($criteria=array()) {
		global $wpdb;
		
		$fb_token_expires = $criteria['fb_token_expires'];
		
		if($fb_token_expires=='') $fb_token_expires=0;
		
		$table_name = $wpdb->prefix . "facebook_wpress";
		$now = time();
		$sql = "SELECT * FROM $table_name WHERE fb_email!='' ORDER BY created DESC";
		$results = $wpdb->get_results($wpdb->prepare($sql));
		for($i=0;$i<count($results);$i++) {
			$data[$i]['fb_id'] = $results[$i]->fb_id;
			$data[$i]['name'] = $results[$i]->fb_name;
			$data[$i]['email'] = $results[$i]->fb_email;
			$data[$i]['picture'] = 'https://graph.facebook.com/'.$results[$i]->fb_id.'/picture';
			$data[$i]['url'] = 'https://www.facebook.com/profile.php?id='.$results[$i]->fb_id;
			$data[$i]['fb_token'] = $results[$i]->fb_token;
			$data[$i]['fb_token_expires'] = $results[$i]->fb_token_expires;
			$data[$i]['created'] = $results[$i]->created;
		}
		return $data;
	}
	
	function checkTableFields() {
		global $wpdb;
		$table_name = $wpdb->prefix . "facebook_wpress";
		
		$sql = "DESCRIBE $table_name";
		$result = $wpdb->get_results($sql, 'ARRAY_N');
		
		for($i=0; $i<count($result); $i++) {
			$field[] = $result[$i][0];
		}
		
		//if "wp_id" doesn't exist, create it
		if(!in_array('wp_id',$field)) {
			$sql = "ALTER TABLE `$table_name` ADD `wp_id` INT NOT NULL AFTER `id`";
			$toto = $wpdb->query($wpdb->prepare($sql));
		}
		
		if(!in_array('fb_birthday',$field)) {
			$sql = "ALTER TABLE `$table_name` ADD `fb_birthday` VARCHAR( 120 ) NOT NULL AFTER `fb_token_expires`";
			$toto = $wpdb->query($wpdb->prepare($sql));
		}
		
		if(!in_array('fb_about_me',$field)) {
			$sql = "ALTER TABLE `$table_name` ADD `fb_about_me` TEXT AFTER `fb_birthday`";
			$toto = $wpdb->query($wpdb->prepare($sql));
		}
	}
	
	function createTable() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . "facebook_wpress";
		
		$sql = "SHOW TABLES LIKE '$table_name'";
		$result = $wpdb->query($sql);
		
		if($result==0) {
			$sql = "CREATE TABLE " . $table_name . " (
			`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
			`fb_id` BIGINT NOT NULL ,
			`fb_name` VARCHAR( 60 ) NOT NULL ,
			`fb_email` VARCHAR( 120 ) NOT NULL ,
			`fb_token` VARCHAR( 120 ) NOT NULL ,
			`fb_token_expires` INT NOT NULL ,
			`fb_birthday` VARCHAR( 120 ) NOT NULL ,
			`fb_about_me` TEXT ,
			`created` DATETIME NOT NULL
			);";
			$wpdb->query($sql);
			
			// ALTER TABLE 'wp_facebook_wpress' ADD 'fb_email' VARCHAR( 120 ) NOT NULL AFTER 'fb_name'
		}
	}
	
	//user is connected with WordPress
	function attach_fb_user_to_wp_user($wp_id) {
		global $wpdb;
		$table_name = $wpdb->prefix . "facebook_wpress";
		
		$f1 = new Facebook_class();
		$fb_cookie = $f1->getCookie();
		if($fb_cookie!='') {
			$user_data = $f1->getUserData();
			$fb_id = $user_data['id'];
			$fb_name = $user_data['name'];
			$fb_profile_picture = $user_data['picture'];
			$fb_link = $user_data['link'];
			$fb_email = $user_data['email'];
			$fb_token = $user_data['token'];
			$fb_token_expires = $user_data['token_expires'];
			
			$today = date('Y-m-d H:i:s');
			
			$sql = "SELECT id FROM $table_name WHERE fb_id='$fb_id' AND wp_id='$wp_id'";
			$results = $wpdb->get_results($sql, 'ARRAY_A');
			if(count($results)==0) {
				$sql = "INSERT INTO $table_name (fb_id, wp_id, fb_name, fb_email, fb_token, fb_token_expires, created) VALUES
				('$fb_id', '$wp_id', '$fb_name', '$fb_email', '".$fb_cookie['access_token']."', '".$fb_cookie['expires']."', '$today')";
				$wpdb->query($wpdb->prepare($sql));
			}
			else {
				//update with last FB values...
				$sql = "UPDATE $table_name SET fb_email='$fb_email', fb_token='$fb_token', fb_token_expires='$fb_token_expires' WHERE fb_id='$fb_id'";
				$wpdb->query($wpdb->prepare($sql));
			}
		}
	}
	
	function on_fb_logout() {
		require_once(ABSPATH . WPINC . '/pluggable.php');
		wp_logout();
	}
	
	function on_fb_connect() {
		global $wpdb;
		$table_name = $wpdb->prefix . "facebook_wpress";
		
		//user is connected with WordPress
		if ( is_user_logged_in() ) {
			require_once(ABSPATH . WPINC . '/pluggable.php');
			$user = wp_get_current_user();
			$wp_id = $user->ID;
			//attach the Fb user to the current connected user
			self::attach_fb_user_to_wp_user($wp_id);
		}
		
		//the user is not connected with WP
		else {
			$f1 = new Facebook_class();
			$fb_cookie = $f1->getCookie();
			
			//print_r('dd: '.$fb_cookie);
			
			//if Facebook session detected
			if($fb_cookie!='') {
				
				$user_data = $f1->getUserData();
				$fb_id = $user_data['id'];
				$fb_email = $user_data['email'];
				$fb_token = $user_data['token'];
				$fb_token_expires = $user_data['token_expires'];
				
				$sql = "SELECT wp_id FROM $table_name WHERE fb_id='$fb_id'";
				$results = $wpdb->get_results($sql, 'ARRAY_A');
				
				//FB user found => update some of his data and connect him
				if(count($results)>0) {
					$wp_id = $results[0]['wp_id'];
					
					$sql = "UPDATE $table_name SET fb_email='$fb_email', fb_token='$fb_token', fb_token_expires='$fb_token_expires' 
					WHERE fb_id='$fb_id'";
					$wpdb->query($wpdb->prepare($sql));
					
					$wc1 = new Facebook_wpress_wp();
					$wc1->connect_the_user($wp_id);
				}
				//create the user
				else {
					self::create_wp_user($user_data);
				}
			}
			else {
				echo 'An error happened';
			}
		}
		
		exit;
	}
	
	function create_wp_user($user_data) {
		global $wpdb;
		$table_name = $wpdb->prefix . "facebook_wpress";
		
		$fb_id = $user_data['id'];
		$username = $user_data['username'];
		$first_name = $user_data['first_name'];
		$last_name = $user_data['last_name'];
		$password = rand(999,9999).rand(999,9999).rand(999,9999);
		$fb_name = $user_data['name'];
		$fb_profile_picture = $user_data['picture'];
		$fb_email = $user_data['email'];
		$fb_link = $user_data['link'];
		$fb_token = $user_data['token'];
		$fb_token_expires = $user_data['token_expires'];
		$fb_birthday = $user_data['birthday'];
		$fb_bio = $user_data['bio'];
		
		//$first_name = $f1->cyrillic_to_english($first_name);
		//$last_name = $f1->cyrillic_to_english($last_name);
		
		$f1 = new Facebook_wpress_wp();
		$valid_username_email = $f1->get_valid_username_email(array('username'=>$username, 'name'=>$fb_name, 'email'=>$fb_email, 'user_id'=>$fb_id));
		
		//echo $username;
		//print_r($valid_username_email);
		
		$username = $valid_username_email['username'];
		$fb_email = $valid_username_email['email'];
		
		//register a new WP user
		$wp_user_data['username'] = $username;
		$wp_user_data['name'] = $fb_name;
		$wp_user_data['first_name'] = $first_name;
		$wp_user_data['last_name'] = $last_name;
		$wp_user_data['email'] = $fb_email;
		$wp_user_data['password'] = $password;
		$wp_user_data['link'] = $fb_link;
		
		$wp_id = $f1->add_wp_user($wp_user_data);
		
		if($wp_id>0) {
			$sql = "INSERT INTO $table_name (wp_id, fb_id, fb_name, fb_email, fb_token, fb_token_expires, fb_birthday, fb_about_me, created) VALUES
			('$wp_id', '$fb_id', '$fb_name', '$fb_email', '$fb_token', '$fb_token_expires', '$fb_birthday', '$fb_bio', '".date('Y-m-d H:i:s')."')";
			$wpdb->query($wpdb->prepare($sql));
			
			self::post_status_on_the_user_wall($user_data);
			
			//log the user in
			$f1->connect_the_user($wp_id);
		}
		
	}
	
	function post_status_on_the_user_wall($user_data) {
		$first_name = $user_data['first_name'];
		$last_name = $user_data['last_name'];
		$token = $user_data['token'];
		
		//get autopost settings
		$options_autopost = get_option(FACEBOOK_WPRESS_ADMIN_AUTOPOST);
		$autopost = $options_autopost['autopost'];
		$picture = $options_autopost['picture'];
		$link = $options_autopost['link'];
		$message = $options_autopost['message'];
		
		if($autopost=='on') {
			
			if($message!='') {
				
				$message = str_replace('{first_name}', $first_name, $message);
				$message = str_replace('{last_name}', $last_name, $message);
				
				$f1 = new Facebook_class();
				$f1->updateFacebookStatus(array('message'=>$message, 'link'=>$link, 'picture'=>$picture), $token);
			}
		}
	}
	
	function get_fb_user($wp_id) {
		global $wpdb;
		$table_name = $wpdb->prefix . "facebook_wpress";
		$sql = "SELECT * FROM $table_name WHERE wp_id='$wp_id'";
		$result = $wpdb->get_results($sql, 'ARRAY_A');
		return $result;
	}
	
	function delete_fb_user($wp_id) {
		global $wpdb;
		$table_name = $wpdb->prefix . "facebook_wpress";
		$sql = "DELETE FROM $table_name WHERE wp_id='$wp_id'";
		$wpdb->query($wpdb->prepare($sql));
	}
}

?>