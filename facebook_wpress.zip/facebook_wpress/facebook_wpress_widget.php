<?php
define(FACEBOOK_WPRESS_ID_login, 'facebook_wpress_id_login');
define(FACEBOOK_WPRESS_ID_friends, 'facebook_wpress_id_friends');
define(FACEBOOK_WPRESS_ID_connected, 'facebook_wpress_id_connected');
define(FACEBOOK_WPRESS_ADMIN_ID, 'facebook_wpress_admin_id');

require_once dirname( __FILE__ ).'/include/webzone.php';

class Facebook_wpress_widget extends WPress_framework {
	
	function Facebook_wpress_widget() {
		// register the widget
		add_action("plugins_loaded",array('Facebook_wpress_widget', 'widget_registration_login'));
		add_action("plugins_loaded",array('Facebook_wpress_widget', 'widget_registration_friends'));
		add_action("plugins_loaded",array('Facebook_wpress_widget', 'widget_registration_connected'));
	}
	
	function setDefaultValues() {
		//Friends
		$criteria['key'] = FACEBOOK_WPRESS_ID_friends;
		$criteria['default_values'] = array('title'=>'Friends', 'nb_friends'=>'10');
		parent::set_default_values($criteria);
		//Last connected
		$criteria2['key'] = FACEBOOK_WPRESS_ID_connected;
		$criteria2['default_values'] = array('title'=>'Last connected', 'nb_connected'=>'10');
		parent::set_default_values($criteria2);
	}
	
	function widget_registration_login() {
		wp_register_sidebar_widget(FACEBOOK_WPRESS_ID_login, 'Facebook WPress Login', array('Facebook_wpress_widget', 'widget_init_login'));
		wp_register_widget_control(FACEBOOK_WPRESS_ID_login, 'Facebook WPress Login', array('Facebook_wpress_widget', 'widget_control_login'));
	}
	
	function widget_registration_friends() {
		wp_register_sidebar_widget(FACEBOOK_WPRESS_ID_friends, 'Facebook WPress Friends', array('Facebook_wpress_widget', 'widget_init_friends'));
		wp_register_widget_control(FACEBOOK_WPRESS_ID_friends, 'Facebook WPress Friends', array('Facebook_wpress_widget', 'widget_control_friends'));
	}
	
	function widget_registration_connected() {
		wp_register_sidebar_widget(FACEBOOK_WPRESS_ID_connected, 'Facebook WPress Connected', array('Facebook_wpress_widget', 'widget_init_connected'));
		wp_register_widget_control(FACEBOOK_WPRESS_ID_connected, 'Facebook WPress Connected', array('Facebook_wpress_widget', 'widget_control_connected'));
	}
	
	function widget_init_login() {
		echo $before_widget;
		$tmp = new Facebook_wpress_widget();
		$tmp->widget_display_login();
		echo $after_widget;
	}
	
	function widget_init_friends() {
		echo $before_widget;
		$tmp = new Facebook_wpress_widget();
		$tmp->widget_display_friends();
		echo $after_widget;
	}
	
	function widget_init_connected() {
		echo $before_widget;
		$tmp = new Facebook_wpress_widget();
		$tmp->widget_display_connected();
		echo $after_widget;
	}
	
	function widget_display_login() {
		$f1 = new Facebook_wpress();
		$display = $f1->get_connect_link_display(array('widget_flag'=>1));
		echo '<div class="widget"><p>';
		echo $display;
		echo '</p></div><br>';
	}
	
	function widget_display_friends() {
		if(is_user_logged_in()) {
			$this->display_friends();
		}
	}
	
	function widget_display_connected() {
		$this->displayConnectedUsers();
	}
	
	function display_friends() {
		$options = get_option(FACEBOOK_WPRESS_ID_friends);
		$nb_friends = $options['nb_friends'];
		//display friends
		if($nb_friends>0) {
			$f1 = new Facebook_class();
			$fb_friends = $f1->getFacebookFriends();
			if(count($fb_friends)>0) {
				echo '<div class="widget">';
				echo $options['title'];
				$fb_friends_display = $f1->displayUsersIcons(array('users'=>$fb_friends, 'nb_display'=>$nb_friends));
				echo '<p style="margin-top:5px;">'.$fb_friends_display.'</p>';
				echo '</div>';
			}
		}
	}
	
	function displayConnectedUsers() {
		$options = get_option(FACEBOOK_WPRESS_ID_connected);
		$nb_connected = $options['nb_connected'];
		
		if($nb_connected>0) {
			require_once dirname( __FILE__ ).'/facebook_wpress_db.php';
			$f1 = new Facebook_wpress_db();
			$users = $f1->getConnectedUsers();
			if(count($users)>0) {
				echo '<div class="widget">';
				$f1 = new Facebook_class();
				$users = $f1->displayUsersIcons(array('users'=>$users, 'nb_display'=>$nb_connected, 'privacy'=>1));
				echo $options['title'];
				echo '<p style="margin-top:5px;">'.$users.'</p>';
				echo '</div>';
			}
		}
	}
	
	function widget_control_login() {
		echo 'Will display the connect button.';
	}
	
	function widget_control_friends() {
		$criteria['key'] = FACEBOOK_WPRESS_ID_friends;
		$criteria['fields'][] = array('name'=>'title', 'title'=>'Title:');
		$criteria['fields'][] = array('name'=>'nb_friends', 'title'=>'Number of friends to show:');
		parent::display_widget_control($criteria);
	}
	
	function widget_control_connected() {
		$criteria['key'] = FACEBOOK_WPRESS_ID_connected;
		$criteria['fields'][] = array('name'=>'title', 'title'=>'Title:');
		$criteria['fields'][] = array('name'=>'nb_connected', 'title'=>'Number of connected users to show:');
		parent::display_widget_control($criteria);
	}
	
}

new Facebook_wpress_widget();

?>