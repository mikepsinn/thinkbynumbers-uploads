<?php

class Facebook_wpress_wp {
	
	
	function add_wp_user($criteria) {
		$username = $criteria['username'];
		$name = $criteria['name'];
		$first_name = $criteria['first_name'];
		$last_name = $criteria['last_name'];
		$password = $criteria['password'];
		$email = $criteria['email'];
		$link = $criteria['link'];
		
		//create the WP user
		require_once(ABSPATH . WPINC . '/registration.php');
		$wp_id = wp_create_user( $username, $password, $email );
		
		if($link!='') wp_update_user( array ('ID' => $wp_id, 'user_url' => $link) );
		
		if($name!='') update_user_meta( $wp_id, 'nickname', $name);
		if($first_name!='') update_user_meta( $wp_id, 'first_name', $first_name );
		if($last_name!='') update_user_meta( $wp_id, 'last_name', $last_name );
		//if($email!='') update_user_meta( $wp_id, 'email', $email );
		
		return $wp_id;
	}
	
	function get_valid_username_email($criteria=array()) {
		$username = $criteria['username'];
		$name = $criteria['name'];
		$user_id = $criteria['user_id'];
		$email = $criteria['email'];
		
		//$fc1 = new Facebook_wpress_conversion();
		//$username = $fc1->cyr2eng($username);
		//$name = $fc1->cyr2eng($name);
		
		require_once(ABSPATH . WPINC . '/registration.php');
		
		if($username!='') $username = str_replace('.','_',$username);
		
		if($username==''||username_exists($username)) {
			$username = self::format_username($name);
		}
		
		if($username!='' && username_exists($username)) {
			for($i=1; $i<10; $i++) {
				$tmp_username = $username.'_'.$i;
				if(!username_exists($tmp_username)) {
					$username = $tmp_username;
					$i=10;
				}
			}
		}
		
		if($username=='') {
			for($i=1; $i<10; $i++) {
				$tmp_username = 'fb_'.$user_id.'_'.$i;
				if(!username_exists($tmp_username)) {
					$username = $tmp_username;
					$i=10;
				}
			}
		}
		
		//email treatments
		if(email_exists($email) || $email=='') {
			$email = $user_id.'@'.$username.'.fake';
			$email = str_replace('_','',$email);
		}
		
		$data['username'] = $username;
		$data['email'] = $email;
		return $data;
	}
	
	function format_username($username) {
		//format the user nicename (until finding a better way...)
		$encoding = mb_detect_encoding($username, 'auto');
		if($encoding=='UTF-8') $username = utf8_decode($username);
	    $a = '��������������������������������������������������������������';
	    $b = 'aaaaaaaceeeeiiiidnoooooouuuuybsaaaaaaaceeeeiiiidnoooooouuuyyby';
	    $username = strtr($username, $a, $b);
	    $username = strtolower($username);
	    $username = eregi_replace("[^a-z0-9]",' ',$username);
		$username = trim($username);
		$username = preg_replace("/ -+/","_",$username);
		$username = preg_replace("/- +/","_",$username);
		$username = preg_replace("/ +/","_",$username);
		$username = str_replace('.','_',$username);
		return $username;
	}
	
	// connects the WP user
	function connect_the_user($wp_id) {
		wp_set_auth_cookie($wp_id, true, false);
	}
}

?>