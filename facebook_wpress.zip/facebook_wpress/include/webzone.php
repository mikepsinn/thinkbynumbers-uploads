<?php
//define('FACEBOOK_APP_ID', 'your_own_facebook_app_id');
//define('FACEBOOK_SECRET', 'your_own_facebook_app_sectet');

//Facebook class
include_once("class/Facebook.class.php");
?>